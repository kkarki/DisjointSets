package org.eclipse.swt.internal.cocoa;

public class SWTSearchFieldCell extends NSSearchFieldCell {

	public SWTSearchFieldCell() {
		super();
	}

	public SWTSearchFieldCell(id id) {
		super(id);
	}

	public SWTSearchFieldCell(long id) {
		super(id);
	}
}
